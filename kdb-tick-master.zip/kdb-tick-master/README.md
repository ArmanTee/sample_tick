# kdb+tick

Files previously at code.kx.com/wsvn/kx/kdb+tick


## Hot-linking

You are welcome to download and use this code according to the terms of the licence. 

Kx Systems recommends you do not link your application to this repository, 
which would expose your application to various risks:

- This is not a high-availability hosting service
- Updates to the repo may break your application 
- Code refactoring might return 404s to your application

Instead, download code and subject it to the version control and regression testing 
you use for your application.
